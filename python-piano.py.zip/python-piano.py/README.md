# 🎹 Python Piano Studio

A browser-based virtual piano built with **Python, Flask, HTML, CSS, JavaScript, and Tone.js**. Play notes with your mouse or computer keyboard, move across the full 88-note piano range, experiment with instrument modes and effects, and record note events.

## Features

- **88-note range:** navigate from A0 to C8 while keeping 36 notes visible at a time.
- **Computer-keyboard play:** 36 mapped keys update with the visible piano range.
- **Mouse/touch play:** click or tap the on-screen piano keys.
- **Instrument modes:** sampled acoustic piano and synthesized digital/electronic piano.
- **Sustain pedal** for longer notes.
- **Metronome** with adjustable tempo.
- **Echo, reverb, and master-volume controls.**
- **Song player:** enter note names such as `C4 D4 E4 F4 G4`.
- **Performance recording:** record note on/off events, play them back, and export them as JSON.
- **Flask app:** serves the app locally from a simple Python backend.

## Requirements

- Python 3.10 or newer recommended
- pip
- An up-to-date browser with Web Audio support
- Internet access for the Tone.js CDN and Salamander piano samples

## Run locally

### 1. Get the project

Clone the repository or download it as a ZIP, then open a terminal in the project folder (the folder containing `app.py`).

### 2. Create and activate a virtual environment

**Windows PowerShell:**

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
```

**macOS/Linux:**

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
python -m pip install -r requirements.txt
```

### 4. Start Flask

```bash
python app.py
```

Open the local address shown in the terminal, usually `http://127.0.0.1:5000`.

> Audio starts after a user interaction in most browsers. Keep an internet connection available so Tone.js and the piano samples can load.

## How to use

1. Click a piano key or press one of the mapped computer keys shown on the piano.
2. Use **Lower notes** and **Higher notes** to navigate the full piano range. The computer-key mapping changes with the visible 36-note window.
3. Choose acoustic or digital/electronic mode.
4. Adjust sustain, metronome tempo, echo, reverb, and volume as desired.
5. Enter note names in the Song Player, separated by spaces or commas, and choose **Play Song**.
6. Use the recording controls to record note events, play them back, or export the events to JSON.

## Audio dependencies and attribution

- **Tone.js 14.8.49** is loaded from jsDelivr in `templates/index.html`.
- Acoustic piano samples are loaded from the [Tone.js Salamander sample library](https://tonejs.github.io/audio/salamander/).
- The HTML credits the **Salamander Grand Piano by Alexander Holm**, under **Creative Commons Attribution 3.0 (CC BY 3.0)**, and links to the [Salamander Grand Piano source repository](https://github.com/sfzinstruments/SalamanderGrandPiano).

The application requires network access for these external assets in its current configuration. If you redistribute or deploy the project, retain the attribution and verify the relevant license terms for the assets you include.

## Project structure

```text
python-piano/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── templates/
│   └── index.html
└── static/
    ├── css/
    │   └── style.css
    └── js/
        └── piano.js
```

## Known limitations

- Acoustic samples and Tone.js are loaded from external URLs, so audio features depend on network access.
- The recorder exports note events as JSON; it does not record microphone input or render an audio file.
- Browser testing is recommended after changes, especially for audio startup, rapid key release, range navigation, and mobile touch behavior.

## Development checks

Check Python syntax:

```bash
python -m py_compile app.py
```

If Flask is installed, smoke-test the route:

```bash
python -c "from app import app; client = app.test_client(); response = client.get('/'); print(response.status_code); assert response.status_code == 200"
```

For JavaScript syntax checking, use Node.js if installed:

```bash
node --check static/js/piano.js
```

## License

Add a project license before inviting reuse or contributions. The piano sample library and Tone.js have their own separate licenses; this repository's license does not replace those terms.
